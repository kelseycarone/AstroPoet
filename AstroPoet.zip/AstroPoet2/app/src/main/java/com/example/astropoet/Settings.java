package com.example.astropoet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }

    public void openMain(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openHomePage(View view) {
        Intent intent = new Intent(this, HomePage.class);
        startActivity(intent);
    }

    public void openUserAgreement(View view) {
        Intent intent = new Intent(this, UserAgreement.class);
        startActivity(intent);
    }

    public void openPrivacyPolicy (View view) {
        Intent intent = new Intent(this, PrivacyPolicy.class);
        startActivity(intent);
    }

}