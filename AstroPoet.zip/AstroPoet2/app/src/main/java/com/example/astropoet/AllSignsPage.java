package com.example.astropoet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class AllSignsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_signs_page);
    }

    public void openHomePage (View view){
        Intent intent = new Intent (this, HomePage.class);
        startActivity(intent);
    }

    public void openSettings (View view){
        Intent intent = new Intent (this, Settings.class);
        startActivity(intent);
    }

    public void openAries (View view){
        Intent intent = new Intent (this, Aries.class);
        startActivity(intent);
    }

    public void openTaurus (View view){
        Intent intent = new Intent (this, Taurus.class);
        startActivity(intent);
    }

    public void openCancer (View view){
        Intent intent = new Intent (this, Cancer.class);
        startActivity(intent);
    }

    public void openLeo (View view){
        Intent intent = new Intent (this, Leo.class);
        startActivity(intent);
    }

    public void openVirgo (View view){
        Intent intent = new Intent (this, Virgo.class);
        startActivity(intent);
    }

    public void openLibra (View view){
        Intent intent = new Intent (this, Libra.class);
        startActivity(intent);
    }

    public void openScorpio (View view){
        Intent intent = new Intent (this, Scorpio.class);
        startActivity(intent);
    }

    public void openSag (View view){
        Intent intent = new Intent (this, Sag.class);
        startActivity(intent);
    }

    public void openCap (View view){
        Intent intent = new Intent (this, Cap.class);
        startActivity(intent);
    }

    public void openAqua (View view){
        Intent intent = new Intent (this, Aqua.class);
        startActivity(intent);
    }

    public void openPisces (View view){
        Intent intent = new Intent (this, Pisces.class);
        startActivity(intent);
    }


}